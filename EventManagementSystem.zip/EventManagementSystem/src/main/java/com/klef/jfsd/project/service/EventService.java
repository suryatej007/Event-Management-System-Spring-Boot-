package com.klef.jfsd.project.service;



public interface EventService {
}
